# Pulse Deriv Analyzer — deployment bundle

## What this bundle contains
- `index.html`: customized dark-pink/light-green Pulse Deriv Analyzer frontend.
- `server.js`: Node.js OAuth backend starter.
- `package.json`: dependencies and Render start script.
- `.gitignore`: excludes secrets.

## Important limitations
I cannot deploy into your DForge, DNS, Render, GitHub, or Deriv accounts from this chat. The files need to be uploaded and configured by you.
The frontend currently contains `YOUR_LEGACY_APP_ID`; replace it with your own public legacy App ID before testing the public feed.
The frontend expects the backend at `https://auth.luopean.site`. Change `AUTH_API` in `index.html` if you use a different deployed backend hostname.

The backend uses an in-memory Express session store, which is suitable only for initial smoke testing, not production. Before using real account access, configure a persistent Redis-compatible session store and review session/token security. Do not place secrets in frontend HTML. The backend does not place trades. Do not add live trading until demo testing is complete.

## Deploy frontend to DForge
1. Upload `index.html` to the public root of `luopean.site`.
2. Open `https://luopean.site/`.
3. Replace `YOUR_LEGACY_APP_ID` with your registered legacy App ID in the HTML before uploading if you want the public market feed to connect.

## Deploy backend to Render
1. Create a GitHub repository and upload `server.js`, `package.json`, `.gitignore` (no secrets).
2. In Render create a Web Service connected to that repo.
3. Build command `npm install`; start command `npm start`.
4. Add environment variables:
   `DERIV_OAUTH_CLIENT_ID` = OAuth client ID (not legacy App ID)
   `DERIV_LEGACY_APP_ID` = legacy App ID (optional)
   `DERIV_REDIRECT_URI` = `https://auth.luopean.site/auth/callback`
   `FRONTEND_ORIGIN` = `https://luopean.site`
   `SESSION_SECRET` = privately generated random secret
   `NODE_ENV` = `production`
5. Add custom domain `auth.luopean.site` in Render and set DNS records exactly as Render specifies.
6. Register the exact redirect URI in your Deriv OAuth app.
7. Visit `https://auth.luopean.site/health`; expected response is `{"ok":true}`.

## Demo verification
- Click Connect Deriv Account, sign in and approve.
- Click Check account access and inspect whether the returned account information identifies the intended demo account.
- Do not place any real trades. This starter includes no order placement endpoint.
