import express from "express";
import session from "express-session";
import crypto from "node:crypto";

const app = express();
const PORT = process.env.PORT || 10000;

const {
  DERIV_OAUTH_CLIENT_ID,
  DERIV_LEGACY_APP_ID = "",
  DERIV_REDIRECT_URI,
  FRONTEND_ORIGIN = "https://luopean.site",
  SESSION_SECRET,
  NODE_ENV = "production"
} = process.env;

if (!DERIV_OAUTH_CLIENT_ID || !DERIV_REDIRECT_URI || !SESSION_SECRET) {
  throw new Error("Missing DERIV_OAUTH_CLIENT_ID, DERIV_REDIRECT_URI, or SESSION_SECRET");
}
if (NODE_ENV === "production" && !DERIV_REDIRECT_URI.startsWith("https://")) {
  throw new Error("DERIV_REDIRECT_URI must use HTTPS in production");
}

app.set("trust proxy", 1);
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("Cache-Control", "no-store");
  next();
});

app.use(session({
  name: "pulse.sid",
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 30 * 60 * 1000
  }
  // IMPORTANT: Express's default MemoryStore is for initial testing only.
  // Before production, configure a persistent Redis-compatible session store.
}));

const allowedOrigins = new Set([
  FRONTEND_ORIGIN,
  "https://www.luopean.site"
]);
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && allowedOrigins.has(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  }
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});

function b64url(buffer) {
  return buffer.toString("base64")
    .replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function randomString(bytes = 32) {
  return b64url(crypto.randomBytes(bytes));
}
function requireOrigin(req, res, next) {
  const origin = req.headers.origin;
  if (origin && !allowedOrigins.has(origin)) {
    return res.status(403).json({ error: "Origin not allowed" });
  }
  next();
}

app.get("/health", (_req, res) => res.json({ ok: true }));

app.get("/auth/login", (req, res) => {
  const verifier = randomString(48);
  const challenge = b64url(crypto.createHash("sha256").update(verifier).digest());
  const state = randomString(24);

  req.session.oauth = { verifier, state, createdAt: Date.now() };
  req.session.save(err => {
    if (err) return res.status(500).send("Could not start login. Please try again.");
    const params = new URLSearchParams({
      response_type: "code",
      client_id: DERIV_OAUTH_CLIENT_ID,
      redirect_uri: DERIV_REDIRECT_URI,
      scope: "trade",
      state,
      code_challenge: challenge,
      code_challenge_method: "S256"
    });
    if (DERIV_LEGACY_APP_ID) params.set("app_id", DERIV_LEGACY_APP_ID);
    res.redirect(302, "https://auth.deriv.com/oauth2/auth?" + params.toString());
  });
});

app.get("/auth/callback", async (req, res) => {
  const { code, state, error } = req.query;
  const pending = req.session.oauth;
  delete req.session.oauth;

  if (error) {
    return req.session.save(() => res.redirect(
      FRONTEND_ORIGIN + "/?deriv_error=" + encodeURIComponent(String(error))
    ));
  }
  if (typeof code !== "string" || typeof state !== "string" ||
      !pending || state !== pending.state ||
      Date.now() - pending.createdAt > 10 * 60 * 1000) {
    return req.session.save(() => res.status(400).send(
      "OAuth state check failed or login expired. Return to luopean.site and try again."
    ));
  }

  try {
    const tokenResponse = await fetch("https://auth.deriv.com/oauth2/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        grant_type: "authorization_code",
        client_id: DERIV_OAUTH_CLIENT_ID,
        code,
        code_verifier: pending.verifier,
        redirect_uri: DERIV_REDIRECT_URI
      })
    });

    const tokenData = await tokenResponse.json();
    if (!tokenResponse.ok || !tokenData.access_token) {
      console.error("Deriv token exchange failed:", tokenResponse.status);
      return res.status(502).send("Deriv login could not be completed. Please retry.");
    }

    // Tokens remain on the backend and are never returned to browser JavaScript.
    req.session.deriv = {
      accessToken: tokenData.access_token,
      expiresAt: Date.now() + Number(tokenData.expires_in || 3600) * 1000
    };
    req.session.cookie.maxAge = Math.min(
      Number(tokenData.expires_in || 3600) * 1000,
      30 * 60 * 1000
    );

    req.session.save(err => {
      if (err) return res.status(500).send("Could not save login session. Please retry.");
      res.redirect(302, FRONTEND_ORIGIN + "/?deriv_connected=1");
    });
  } catch (e) {
    console.error("OAuth callback network error:", e.message);
    res.status(502).send("Could not contact Deriv. Please try again.");
  }
});

app.get("/api/session", requireOrigin, (req, res) => {
  const auth = req.session.deriv;
  if (!auth || auth.expiresAt <= Date.now()) {
    delete req.session.deriv;
    return res.json({ connected: false });
  }
  res.json({ connected: true, expiresAt: auth.expiresAt });
});

app.get("/api/accounts", requireOrigin, async (req, res) => {
  const auth = req.session.deriv;
  if (!auth || auth.expiresAt <= Date.now()) {
    delete req.session.deriv;
    return res.status(401).json({ error: "Not connected. Sign in with Deriv first." });
  }

  try {
    const upstream = await fetch("https://api.derivws.com/trading/v1/options/accounts", {
      headers: { Authorization: `Bearer ${auth.accessToken}` }
    });
    const data = await upstream.json();
    if (!upstream.ok) {
      console.error("Deriv accounts request failed:", upstream.status);
      return res.status(upstream.status === 401 ? 401 : 502).json({
        error: "Deriv account request failed. Check OAuth permissions and app setup."
      });
    }
    // Only return the response needed for demo verification; never return the token.
    res.json({ ok: true, accounts: data });
  } catch (e) {
    console.error("Deriv accounts network error:", e.message);
    res.status(502).json({ error: "Could not reach Deriv account API." });
  }
});

app.post("/auth/logout", requireOrigin, (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("pulse.sid", {
      httpOnly: true,
      secure: NODE_ENV === "production",
      sameSite: "lax",
      path: "/"
    });
    res.json({ ok: true });
  });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Pulse Deriv auth backend listening on ${PORT}`);
});
